const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

const DATA_FILE = path.join(__dirname, 'data.json');
async function readData() { return fs.readJson(DATA_FILE); }
async function writeData(data) { return fs.writeJson(DATA_FILE, data, { spaces: 2 }); }

// Lista transakcji
app.get('/api/transactions', async (req, res) => {
  const { transactions } = await readData();
  res.json(transactions);
});

// Dodawanie transakcji
app.post('/api/transactions', async (req, res) => {
  const { description, amount, type, date, category } = req.body;
  const data = await readData();
  const newTx = { id: uuidv4(), description, amount, type, date, category };
  data.transactions.push(newTx);
  await writeData(data);
  res.status(201).json(newTx);
});

// Usuwanie pojedynczej transakcji
app.delete('/api/transactions/:id', async (req, res) => {
  const id = req.params.id;
  const data = await readData();
  data.transactions = data.transactions.filter(t => t.id !== id);
  await writeData(data);
  res.status(204).end();
});

// Usuwanie wszystkich transakcji
app.delete('/api/transactions', async (req, res) => {
  const data = await readData();
  data.transactions = [];
  await writeData(data);
  res.status(204).end();
});

// Podstawowy raport (suma)
app.get('/api/report', async (req, res) => {
  const { transactions } = await readData();
  const totalIncome  = transactions.filter(t => t.type === 'income').reduce((a, t) => a + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((a, t) => a + t.amount, 0);
  res.json({ totalIncome, totalExpense });
});

// Raport roczny
app.get('/api/report/yearly', async (req, res) => {
  const year = parseInt(req.query.year) || new Date().getFullYear();
  const { transactions } = await readData();
  const yearTx = transactions.filter(t => new Date(t.date).getFullYear() === year);
  const totalIncome  = yearTx.filter(t => t.type==='income').reduce((a, t) => a + t.amount, 0);
  const totalExpense = yearTx.filter(t => t.type==='expense').reduce((a, t) => a + t.amount, 0);
  res.json({ year, totalIncome, totalExpense });
});

// Raport miesięczny
app.get('/api/report/monthly', async (req, res) => {
  const year = parseInt(req.query.year) || new Date().getFullYear();
  const { transactions } = await readData();
  const months = Array.from({ length: 12 }, (_,i) => ({ month: i+1, income:0, expense:0 }));
  transactions.forEach(t => {
    const d = new Date(t.date);
    if (d.getFullYear() === year) {
      const m = d.getMonth();
      if (t.type === 'income') months[m].income += t.amount;
      else months[m].expense += t.amount;
    }
  });
  res.json({ year, monthly: months });
});

const PORT = 4000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
