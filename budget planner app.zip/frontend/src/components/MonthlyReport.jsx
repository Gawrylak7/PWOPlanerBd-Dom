import React, { useEffect, useState } from 'react';
import axios from 'axios';

const months = ['Sty','Lu','Mar','Kw','Maj','Cze','Lip','Sie','Wrz','Pa','Lis','Gru'];

export default function MonthlyReport({ transactions, year }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:4000/api/report/monthly?year=${year}`)
      .then(r => setData(r.data));
  }, [transactions, year]);

  if (!data) return <p>Ładowanie...</p>;
  return (
    <div className="mb-6 p-4 bg-white rounded shadow overflow-auto">
      <h2 className="text-xl font-semibold mb-2">Raport Miesięczny {data.year}</h2>
      <table className="w-full text-left">
        <thead>
          <tr>
            <th className="p-2">Miesiąc</th>
            <th>Przychody</th>
            <th>Wydatki</th>
            <th>Saldo</th>
          </tr>
        </thead>
        <tbody>
          {data.monthly.map(m => (
            <tr key={m.month} className="border-t">
              <td className="p-2">{months[m.month - 1]}</td>
              <td>{m.income.toFixed(2)}</td>
              <td>{m.expense.toFixed(2)}</td>
              <td>{m.income.toFixed(2) - m.expense.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}