import React from 'react';
import axios from 'axios';

export default function TransactionList({ transactions, onDelete }) {
  const expenses = transactions.filter(t => t.type === 'expense');
  const incomes = transactions.filter(t => t.type === 'income');

  const del = id => axios
    .delete(`http://localhost:4000/api/transactions/${id}`)
    .then(onDelete);

  return (
    <div className="mb-6">
      <h2 className="text-xl font-semibold mb-2">Wydatki</h2>
      <ul className="space-y-2 mb-4">
        {expenses.map(t => (
          <li key={t.id} className="flex justify-between border p-2 rounded bg-red-50">
            <span>{t.date} – {t.description} ({t.category})</span>
            <span>-{t.amount.toFixed(2)} PLN <button onClick={() => del(t.id)} className="text-red-600">Usuń</button></span>
          </li>
        ))}
      </ul>
      <h2 className="text-xl font-semibold mb-2">Przychody</h2>
      <ul className="space-y-2">
        {incomes.map(t => (
          <li key={t.id} className="flex justify-between border p-2 rounded bg-green-50">
            <span>{t.date} – {t.description} ({t.category})</span>
            <span>+{t.amount.toFixed(2)} PLN <button onClick={() => del(t.id)} className="text-red-600">Usuń</button></span>
          </li>
        ))}
      </ul>
    </div>
  );
}
