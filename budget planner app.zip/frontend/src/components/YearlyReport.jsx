import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function YearlyReport({ transactions, year }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:4000/api/report/yearly?year=${year}`)
      .then(r => setData(r.data));
  }, [transactions, year]);

  if (!data) return <p>Ładowanie...</p>;
  return (
    <div className="mb-6 p-4 bg-white rounded shadow">
      <h2 className="text-xl font-semibold mb-2">Raport Roczny {data.year}</h2>
      <p>Przychody: {data.totalIncome.toFixed(2)} PLN</p>
      <p>Wydatki: {data.totalExpense.toFixed(2)} PLN</p>
      <p>Saldo: {data.totalIncome.toFixed(2) - data.totalExpense.toFixed(2)} PLN</p>
    </div>
  );
}