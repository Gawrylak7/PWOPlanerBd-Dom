import React from 'react';

export default function YearSelector({ year, onChange }) {
  // Zakres lat: od 2020 do 2030
  const startYear = 2020;
  const endYear = 2030;
  const years = [];
  for (let y = endYear; y >= startYear; y--) {
    years.push(y);
  }

  return (
    <select
      value={year}
      onChange={e => onChange(parseInt(e.target.value, 10))}
      className="border p-2 rounded mb-4"
      required
    >
      <option value="" disabled>Wybierz rok...</option>
      {years.map(y => (
        <option key={y} value={y}>{y}</option>
      ))}
    </select>
  );
}
