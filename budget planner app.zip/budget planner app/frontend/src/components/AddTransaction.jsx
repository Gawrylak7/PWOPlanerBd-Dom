import React, { useState } from 'react';
import axios from 'axios';

const expenseCats = ['Jedzenie','Mieszkanie','Samochód','Zwierzeta','Zdrowie','Nauka','Hobby','Sport','Inne'];
const incomeCats = ['Praca','Kieszonkowe','Dodatkowe prace','Hobby','Inwestycje','Oszczędności','Rodzina','Inne'];

export default function AddTransaction({ onAdd }) {
  const [form, setForm] = useState({
    date: '',
    description: '',
    amount: '',
    type: '',
    category: ''
  });

 const handleChange = e => {
  const { name, value } = e.target;
  if (name === 'amount' && !/^\d*\.?\d*$/.test(value)) return;
  
  if (name === 'type') {
    // przy zmianie typu transakcji czyścimy też kategorię
    setForm(prev => ({
      ...prev,
      type: value,
      category: ''
    }));
  } else {
    setForm(prev => ({
      ...prev,
      [name]: value
    }));
  }
};

  const handleSubmit = async e => {
    e.preventDefault();
    // walidacja wymaganych pól
    if (!form.type) {
      alert('Proszę wybrać typ transakcji.');
      return;
    }
    if (!form.category) {
      alert('Proszę wybrać kategorię.');
      return;
    }
    const amt = parseFloat(form.amount);
    if (!(amt > 0)) {
      alert('Kwota musi być większa od 0.');
      return;
    }
    const rounded = parseFloat(amt.toFixed(2));
    await axios.post('http://localhost:4000/api/transactions', {
      ...form,
      amount: rounded
    });
    // reset formularza
    setForm({
      date: '',
      description: '',
      amount: '',
      type: '',
      category: ''
    });
    onAdd();
  };

  // lista kategorii zależna od typu
  const cats = form.type === 'expense' ? expenseCats : incomeCats;

  return (
    <form onSubmit={handleSubmit} className="flex flex-wrap gap-2 mb-6">
      <input
        type="date"
        name="date"
        value={form.date}
        onChange={handleChange}
        className="border p-2 rounded"
        required
      />

      <input
        name="description"
        placeholder="Opis"
        value={form.description}
        onChange={handleChange}
        className="border p-2 rounded flex-1"
        required
      />

      <input
        name="amount"
        placeholder="Kwota"
        value={form.amount}
        onChange={handleChange}
        className="border p-2 rounded w-24"
        required
      />

      <select
        name="type"
        value={form.type}
        onChange={handleChange}
        className="border p-2 rounded"
        required
      >
        <option value="" disabled>Wybierz typ...</option>
        <option value="expense">Wydatek</option>
        <option value="income">Przychód</option>
      </select>

      <select
        name="category"
        value={form.category}
        onChange={handleChange}
        className="border p-2 rounded"
        required
      >
        <option value="" disabled>Wybierz kategorię...</option>
        {cats.map(c => (
          <option key={c} value={c}>{c}</option>
        ))}
      </select>

      <button type="submit" className="bg-blue-500 text-white px-4 rounded">
        Dodaj
      </button>
    </form>
  );
}
