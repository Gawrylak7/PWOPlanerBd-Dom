import React, { useEffect, useState } from 'react';

export default function ReportSummary({ transactions }) {
  const [totals, setTotals] = useState({ income: 0, expense: 0 });
  const [byCategory, setByCategory] = useState({ income: {}, expense: {} });
  const [showIncomeDetails, setShowIncomeDetails] = useState(false);
  const [showExpenseDetails, setShowExpenseDetails] = useState(false);

  useEffect(() => {
    const inc = transactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    const exp = transactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    // kategorie
    const incCat = transactions
      .filter(t => t.type === 'income')
      .reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount;
        return acc;
      }, {});
    const expCat = transactions
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount;
        return acc;
      }, {});

    setTotals({ income: inc, expense: exp });
    setByCategory({ income: incCat, expense: expCat });
  }, [transactions]);

  return (
    <div className="mb-6 space-y-4">
      <div className="grid grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded shadow text-center">
          <h3 className="font-semibold">Przychody</h3>
          <p className="text-lg">{totals.income.toFixed(2)} PLN</p>
          <button onClick={() => setShowIncomeDetails(!showIncomeDetails)} className="mt-2 text-blue-500">
            {showIncomeDetails ? 'Ukryj szczegóły' : 'Pokaż szczegóły'}
          </button>
        </div>
        <div className="p-4 bg-white rounded shadow text-center">
          <h3 className="font-semibold">Wydatki</h3>
          <p className="text-lg">{totals.expense.toFixed(2)} PLN</p>
          <button onClick={() => setShowExpenseDetails(!showExpenseDetails)} className="mt-2 text-blue-500">
            {showExpenseDetails ? 'Ukryj szczegóły' : 'Pokaż szczegóły'}
          </button>
        </div>
        <div className="p-4 bg-white rounded shadow text-center">
          <h3 className="font-semibold">Saldo</h3>
          <p className="text-lg">{(totals.income - totals.expense).toFixed(2)} PLN</p>
        </div>
      </div>

      {showIncomeDetails && (
        <div className="p-4 bg-white rounded shadow">
          <h4 className="font-semibold mb-2">Szczegóły przychodów:</h4>
          <ul className="list-disc list-inside">
            {Object.entries(byCategory.income).map(([cat, val]) => (
              <li key={cat}>{cat}: {val.toFixed(2)} PLN</li>
            ))}
          </ul>
        </div>
      )}

      {showExpenseDetails && (
        <div className="p-4 bg-white rounded shadow">
          <h4 className="font-semibold mb-2">Szczegóły wydatków:</h4>
          <ul className="list-disc list-inside">
            {Object.entries(byCategory.expense).map(([cat, val]) => (
              <li key={cat}>{cat}: {val.toFixed(2)} PLN</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );}