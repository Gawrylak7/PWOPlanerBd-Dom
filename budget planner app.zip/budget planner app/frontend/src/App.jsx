import React, { useState, useEffect } from 'react';
import axios from 'axios';
import YearSelector from './components/YearSelector.jsx';
import ReportSummary from './components/ReportSummary.jsx';
import YearlyReport from './components/YearlyReport.jsx';
import MonthlyReport from './components/MonthlyReport.jsx';
import AddTransaction from './components/AddTransaction.jsx';
import TransactionList from './components/TransactionList.jsx';

export default function App() {
  const [allTx, setAllTx] = useState([]);
  const [tx, setTx] = useState([]);
  const [year, setYear] = useState(new Date().getFullYear());

  const fetchAll = () => axios.get('http://localhost:4000/api/transactions')
    .then(r => setAllTx(r.data));

  useEffect(() => { fetchAll(); }, []);

  useEffect(() => {
    // filtruj lokalnie po roku
    setTx(allTx.filter(t => new Date(t.date).getFullYear() === year));
  }, [allTx, year]);

  const deleteAll = () => axios.delete('http://localhost:4000/api/transactions')
    .then(fetchAll);

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold ">Planer Budżetu Domowego</h1>
        <button onClick={deleteAll} className="bg-red-500 text-white px-4 py-2 rounded">Usuń wszystko</button>
      </div>
      <YearSelector year={year} onChange={setYear} />
      <ReportSummary transactions={tx} />
      <YearlyReport transactions={tx} year={year} />
      <MonthlyReport transactions={tx} year={year} />
      <AddTransaction onAdd={fetchAll} />
      <TransactionList transactions={tx} onDelete={fetchAll} />
    </div>
  );
}